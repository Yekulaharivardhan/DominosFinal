import React from "react";
// import { Link } from "react-router-dom";
// import { Route } from "react-router-dom";
import FormField from "./LoginFormTwo";
import "./modal.css";
import PlaceOrderPage from './FullModal';
import { CartProvider } from 'react-use-cart';

function BsModalTwo() {
  return (
    <div>
      <a 
        href="/"
        type="link"
        className="btn-bd-primary"
        data-toggle="modal"
        data-target="#exampleModalScrollable"
      alt='' style={{textDecoration:"none", color:"white"}}>
        CHECKOUT
      </a>
      <div
        className="modal fade"
        id="exampleModalScrollable"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalScrollableTitle"
        aria-hidden="true" style={{height:"820px"}}
      >
        <div className="modal-dialog modal-dialog" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <button type="button" className="close" data-dismiss="modal" aria-label="Close" ></button>
            </div>
            <div className="modal-body">
              <div className="SideBarContainer loginSideBar">
                {/* <div className="esc-btn crss-icn-rght">
         <span>esc</span>
         <div className="injectStyles-sc-1jy9bcf-0 EscButtonCrossIcon">
         </div>
      </div> */}

                <div className="overlay"></div>

                <div className="side-nav">
                  <div className="ovrly-child">
                    <div>
                      <div className="main LogoContainer">
                        <img
                          className="background_image"
                          src="https://pizzaonline.dominos.co.in/static/assets/login_pizza_image.png"
                          srcSet="https://pizzaonline.dominos.co.in/static/assets/login_pizza_image.png 1x, https://pizzaonline.dominos.co.in/static/assets/login_pizza_image@2x.png 2x, https://pizzaonline.dominos.co.in/static/assets/login_pizza_image@3x.png 3x"
                          alt=""
                        />
                        <img
                          className="logo_image"
                          src="https://pizzaonline.dominos.co.in/static/assets/Dominos_logo.svg"
                          alt=""
                        />
                        <div className="login-image">
                          <div className="login-image__txt">
                            <span>Login</span> to unlock awesome new features
                          </div>
                          <div className="login-image__sbtxt">
                            <div>
                              <img
                                src="https://pizzaonline.dominos.co.in/static/assets/icons/great_food.svg"
                                alt=""
                              />
                              <div className="login-image_subtext_image-text">
                                <p>Great</p>
                                <p>Food</p>
                              </div>
                            </div>
                            <div>
                              <img
                                src="https://pizzaonline.dominos.co.in/static/assets/icons/great_offers.svg"
                                alt=""
                              />
                              <div className="login-image_subtext_image-text">
                                <p>Great</p>
                                <p>Offers</p>
                              </div>
                            </div>
                            <div>
                              <img
                                src="https://pizzaonline.dominos.co.in/static/assets/icons/easy_reorder.svg"
                                alt=""
                              />
                              <div className="login-image_subtext_image-text">
                                <p>Easy</p>
                                <p>Reordering</p>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="injectStyles-src LoginPlaceholderbox">
                          <div className="login_container">
                            <div className="injectStyles-src msg_container">
                              {" "}
                              Login with your valid mobile number
                            </div>

                            <FormField />
                            <CartProvider>
                          <PlaceOrderPage/>
                            </CartProvider>
                          </div>
                        </div>
                        <div className="injectStyles-src login_Socialbtn_cls">
                          <div className="sc-kafWEX LoginSocialtxtalig">
                            <div className="injectStyles-src LoginSocialActsbox">
                              {" "}
                              Login with social accounts
                            </div>
                            <div className="scl--cntr">
                              <div>
                                <div className="injectStyles-src login_button_cls">
                                  <button className="btn--blue">
                                    <div className="injectStyles-src ddacmF"></div>
                                    <span>Facebook</span>
                                  </button>
                                </div>
                              </div>
                              <div type="button" className="google">
                                <div className="injectStyles-src login_button_cls">
                                  <button className="btn--red">
                                    <div className="injectStyles-src clqeyD"></div>
                                    <span>
                                      <a
                                        href="https://accounts.google.com/o/oauth2/auth/oauthchooseaccount?redirect_uri=storagerelay%3A%2F%2Fhttps%2Fpizzaonline.dominos.co.in%3Fid%3Dauth520759&response_type=permission%20id_token&scope=email%20profile%20openid&openid.realm&include_granted_scopes=true&client_id=928101681689-fhhil6jq8g1ftone3bdrt3gfq03bilob.apps.googleusercontent.com&ss_domain=https%3A%2F%2Fpizzaonline.dominos.co.in&prompt&fetch_basic_profile=true&gsiwebsdk=2&flowName=GeneralOAuthFlow"
                                        style={{
                                          textDecoration: "none",
                                          color: "white",
                                        }}
                                        rel="noopener"
                                      >
                                        {" "}
                                        Google{" "}
                                      </a>
                                    </span>
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="lwr-actns">
                          <span>TERMS OF USE</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* <div className="modal-footer">
        <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" className="btn btn-primary">Save changes</button>
      </div> */}
          </div>
        </div>
      </div>{" "}
    </div>
  );
}

export default BsModalTwo;





// const mYId = document.getElementById("mobilenumber").value;

// function valiDation(){

//   if (mYId.length > 10 && mYId.value.match(/[0-9]/)) {
//             alert("Success");
//           } else {
//             alert("Please check Mobile Number");
//           }
// }
