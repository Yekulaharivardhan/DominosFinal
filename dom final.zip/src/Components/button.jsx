import React from 'react';

import './itemcard.css'
import { useCart } from 'react-use-cart';





const ItemCard = (props) =>{
  const {
    addItem,
    isEmpty,
    item,
    updateItemQuantity,
    totalUniqueItems,

  } = useCart();
  if(addItem.length >2){console.log("Greater Than two")}
  else{
    (console.log("less than "))
  }
}


export default ItemCard