import React, { Component } from 'react';
import './navBarTwo.css';
import BsModal from './modal';



class NavBar extends Component {
    state = {  } 
    render() { 
        return (


<nav className="navbar navbar-expand ">
  {/* <div className="container-fluid"> */}

  <div className="Main- Main_Container_Class">
  <div className="tp-hdr">
<div className="hamburger">
              <span></span>
              <span></span>
              <span></span>
            </div>
            
            <img
              className="brand-logo"
              src="https://pizzaonline.dominos.co.in/static/assets/logo_white.svg"
              alt="dominos logo"
              
            />
            <div className="addr-prf-cnt">
            <div className="tp--grp">
              <div className="sc-gzVnrw nav_Bar_right_Container">
                <div className="sc-bZQynM nav_Bar_right_Container_subcls">
                  <label className=" container" data-label="Order_Type_Deliver">
                    <input type="radio" readOnly="" name="deliveryType" />
                    <span>Delivery</span>

                    <span className="checkmark">
                      <span className="checked"></span>
                    </span>
                  </label>
                </div>
                <div className="sc-bZQynM nav_Bar_right_Container_subcls">
                  <label
                    className="non--slctd container"
                    data-label="Order_Type_Pickup"
                  >
                    <input type="radio" readOnly="" name="deliveryType" />

                    <span>Pick Up/Dine-in</span>

                    <span className="checkmark"></span>
                  </label>
                </div>
              </div>
            </div>
            
            <div className="slct-lctn">
            <div className="slct-lctn-cnt">
                <div className="slct-lctn-txt selected_location-txt">
                  <img
                    src="https://pizzaonline.dominos.co.in/static/assets/icons/location_white.png"
                    alt=""
                  />
                  HYDERABAD
                </div>
              
</div>
</div>
            <div data-label="my-account" className="prf-grp-txt">
                <div>MY ACCOUNT</div>
                <div className="prf-grp-txt-hd">
                  <div className="prf-grp-txt-hd">  {<BsModal />} </div>
            
            </div>
            
            </div></div>
            





            
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    
      
    </div></div>
  {/* </div> */}
</nav>



  

        );
    }
}
 
export default NavBar;