import React from 'react';
//  import './card.css'
import './itemcard.css'
import { useCart } from 'react-use-cart';
 


// function CustomeStyle (props){ (<div className="itm-dsc__actn__adCrt">
// <div className="injectStyles-sc-1jy9bcf-0 jrxrSi">
// <button data-label="addTocart">
// <span >ADD TO CART</span></button></div></div>)
// }


// function CustomeStyleTwo (props){(
//   <div className="itm-dsc__actn__adCrt">
//             <div className="sc-kAzzGY beBJOM" data-label="quantity">
//              <div className="injectStyles-sc-1jy9bcf-0 kYAlCU" data-label="decrease"  >--</div>
//              <span className="cntr-val">{props.price}</span>
//              <div>
//              <div className="injectStyles-sc-1jy9bcf-0 gwKvJy" data-label="increase">++</div></div></div>
//            </div> )}




const ItemCard = (props) =>{
  const {
    addItem,
    // removeItem,
    // isEmpty,
    //  items,
    //  updateItemQuantity,
    // totalUniqueItems,

  } = useCart(); 
  // if(isEmpty) 


    return(


<div className="col-11 col-md-1 col-md-4 p-1" style={{marginBottom:"0px", marginRight:"0px"}}>
  <div className='card shadow-lg  mb-1  bg-body rounded' style={{width: "15rem",}}>
  <div className="cardtop" style={{position:"relative"}}>
<img className="card-img-top " src={props.img} alt=" " style={{width:"100%"}} />
<div className="card-title" style={{position:"absolute", bottom:"-6px", left:"16px",color:"white",fontWeight:"bolder"}}>₹{props.price}</div>
</div>
  <div className="card-body " >
    <h5 className="card-title">{props.title}</h5>
    <p className="card-text" style={{fontSize:"13px"}}>{props.desc}</p>


    

    <div id='addtocart' type="button" className="btn btn-outline border-success btn-sm"  onClick={() =>addItem(props.item)}><p>
    ADD TO CART
    </p>
    </div>
   

    
  </div></div></div>
 
    )
    }
export default ItemCard