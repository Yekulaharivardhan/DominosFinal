import React from 'react';
//  import './card.css'
// import './itemcard.css'
import { useCart } from 'react-use-cart';



const ItemCard = (props) =>{
const {addItem} = useCart();
if (addItem.length  > 0){
  console.log(addItem.length)
}



    return(
       

<div className="col-11 col-md-1 col-lg-4 p-4">
  <div className='card shadow-lg  mb-5  bg-body rounded' style={{width: "15rem",}}>
<img className="card-img-top " src={props.img} alt=" " />
  <div className="card-body " >
    <h5 className="card-title">{props.title}</h5>
    <p className="card-title">₹{props.price}</p>
    <p className="card-text" style={{fontSize:"13px"}}>{props.desc}</p>



    <button type="button" className="injectStyles-sc-1jy9bcf-0 kYAlCU"  onClick={() =>addItem(props.item)}>Add to cart</button>
  </div></div></div>
 

          
        
    )
}

export default ItemCard