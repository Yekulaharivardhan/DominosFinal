import React, { Component } from "react";
import ItemCard from "./itemcard";
import data from "./data";



class HomePage extends Component {
  state = {};
  render() {
    return (
      <div>
        <h1 className='text-center mt-3"'>All itmes</h1>
        <section className="py-4 container">
          <div className="row justify-content-center">
            {data.productData.map((item) => {
              return (
                <ItemCard
                  key={item.id}
                  img={item.img}
                  title={item.title}
                  desc={item.desc}
                  price={item.price}
                  item={item}
                />
              );
            })}
          </div>
        </section>
      </div>
    );
  }
}

export default HomePage;
